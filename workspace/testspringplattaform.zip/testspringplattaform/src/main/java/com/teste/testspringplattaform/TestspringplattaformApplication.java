package com.teste.testspringplattaform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestspringplattaformApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestspringplattaformApplication.class, args);
	}

}
