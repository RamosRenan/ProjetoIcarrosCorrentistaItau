package com.teste.testspringplattaform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestspringplattaformApplicationTests {

	@Test
	void contextLoads() {
	}

}
