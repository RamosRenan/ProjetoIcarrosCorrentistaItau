package com.origin.webcurriculo.webcurriculo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebcurriculoApplicationTests {

	@Test
	void contextLoads() {
	}

}
