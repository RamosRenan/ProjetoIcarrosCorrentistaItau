package com.origin.webcurriculo.webcurriculo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebcurriculoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebcurriculoApplication.class, args);
	}

}
