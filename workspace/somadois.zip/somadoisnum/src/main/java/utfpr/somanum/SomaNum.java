/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/J2EE/EJB30/StatelessEjbClass.java to edit this template
 */
package utfpr.somanum;

import javax.ejb.Stateless;

/**
 *
 * @author renan
 */
@Stateless
public class SomaNum {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    public SomaNum(){}

    private int resp = 0;
    public void somaNum(int a, int b)
    {
        resp = a + b;
    }
    
    public int getResp()
    {
        return resp;
    }
}
