/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package utfpr.somanum;

import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.Dependent;
import javax.enterprise.context.RequestScoped;
import javax.ws.rs.FormParam;
import javax.ws.rs.PATCH;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

/**
 *
 * @author renan
 */
@Named(value = "somaDoisCDIBean")
@RequestScoped
public class SomaDoisCDIBean {
    
    private int a,b;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    @EJB
    private SomaNum somaNum;

    /**
     * Creates a new instance of SomaDoisCDIBean
     */
    public SomaDoisCDIBean() {
    }
    
    public void somar()
    {
        System.out.println("-----> Valor A:"+a+"\n"+"-----> Valor A:"+b);
        somaNum.somaNum(a, b);
    }
    
    public int getResp()
    {
        if(somaNum.getResp() == 0)
            return 0;
        return somaNum.getResp();
    }
}
