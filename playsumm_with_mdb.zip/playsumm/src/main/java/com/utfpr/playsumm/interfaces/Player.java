/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.utfpr.playsumm.interfaces;

import javax.ejb.Local;

/**
 *
 * @author renan
 */
@Local
public interface Player {
    public void storePoints();
}
